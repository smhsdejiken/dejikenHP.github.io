 setInterval(function() {
   document.getElementById("d2").innerHTML = new Date().toLocaleString();
 }, 1000);